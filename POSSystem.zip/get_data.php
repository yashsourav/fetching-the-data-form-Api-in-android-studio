<?php

include 'DatabaseConfig.php' ;
 
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
 $categoryname = $_POST['categoryname'];
 $producttype = $_POST['producttype'];
  $brandname = $_POST['brandname'];
  $stock = $_POST['stock'];
  $price = $_POST['price'];

 $Sql_Query = "insert into addproduct (categoryname,producttype,brandname,stock,price) values ('$categoryname','$producttype','$brandname','$stock','$price')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>